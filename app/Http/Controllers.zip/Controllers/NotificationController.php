<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\City;
use App\Models\Notification;
use Session;
use Auth;


class NotificationController extends Controller
{
   
}
