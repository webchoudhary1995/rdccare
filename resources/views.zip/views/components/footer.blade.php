<div class="auto-container">
                    <div class="inner-box clearfix">
                    <div class="row">
                    <div class="col-12 copyright pull-left" style="display: flex; align-items: center;">
                    <p style="color:#FFFFFF"><b>{{__("message.Our_Presence")}} </b> </p>
                    <hr style="border-color: #FFFFFF; flex-grow: 1;">
                    </div>
                    </div>

                     <div class="row">
                         
                         <div class="col-12  copyright pull-left">
                             <p style="color:#FFFFFF"><small>item</small>,</p>
                         </div>
                         
                         
                     </div>
                     <!--#------------------------------------------------------------------------------->
                     <div class="inner-box clearfix">
                     <div class="row">
                        
                        <div class="col-12 copyright pull-left" style="display: flex; align-items: center;">
                        <p style="color:#FFFFFF"><b>{{__("message.Browse_Popular_Blood_Tests")}} </b> </p>
                        <hr style="border-color: #FFFFFF; flex-grow: 1;">
                    </div>
                     </div>
                     <div class="row">
                         <div class="col-12  copyright pull-left">
                             <p style="color:#FFFFFF"><small>item</small>,</p>
                         </div>
                         
                     </div>
                     
                     
                  </div>
                  <!--#------------------------------------------------------------->
                  <div class="inner-box clearfix">
                     <div class="row">
                        
                        <div class="col-12 copyright pull-left" style="display: flex; align-items: center;">
                        <p style="color:#FFFFFF"><b>{{__("message.Browse_Popular_Blood_Packages")}} </b> </p>
                        <hr style="border-color: #FFFFFF; flex-grow: 1;">
                    </div>
                     </div>
                     <div class="row">
                         <div class="col-12  copyright pull-left">
                             <p style="color:#FFFFFF"><small>item</small>,</p>
                         </div>
                         
                     </div>
                     
                     
                  </div>
                <!--#------------------------------------------------------------->
                  <div class="inner-box clearfix">
                     <div class="row">
                        
                        <div class="col-12 copyright pull-left" style="display: flex; align-items: center;">
                        <p style="color:#FFFFFF"><b>{{__("message.Browse_Tests_by_Lifestyl_Disorder")}} </b> </p>
                        <hr style="border-color: #FFFFFF; flex-grow: 1;">
                    </div>
                     </div>
                     <div class="row">
                         <div class="col-12  copyright pull-left">
                             <p style="color:#FFFFFF"><small>item</small>,</p>
                         </div>
                         
                         
                     </div>
                     
                     
                  </div>
                     
                     
                     
                  </div>
                  

               </div>