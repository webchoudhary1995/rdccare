<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
		Hello,
		<div style="width:100%">
		    Order No : {{$user['order_id']}}
		</div>
		<div style="width:100%">
		   {{$user['msg']}}
		</div>
	
</body>
</html>