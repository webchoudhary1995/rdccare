<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
		Hello,
		<div style="width:100%">
		  <?=html_entity_decode($user['msg'])?>
		</div>
	
</body>
</html>