@extends('front.layout')
@section('title')
    {{ $title }}
@stop
@section('meta-data')
<meta property="og:type" content="website"/>
<meta property="og:url" content="{{route('aboutus')}}"/>
<meta property="og:title" content="{{__('message.site_name')}}"/>
<meta property="og:image" content="{{asset('public/img/').'/'.$setting->logo}}"/>
<meta property="og:image:width" content="250px"/>
<meta property="og:image:height" content="250px"/>
<meta property="og:site_name" content="{{__('message.site_name')}}"/>
<meta property="og:description" content="{{__('message.meta_description')}}"/>
<meta property="og:keyword" content="{{__('message.meta_keyword')}}"/>
<link rel="shortcut icon" href="{{asset('public/img/').'/'.$setting->favicon}}">
<meta name="viewport" content="width=device-width, initial-scale=1">
@stop
@section('content')
<section class="page-title-two">
            <div class="title-box centred bg-color-2">
                <div class="pattern-layer">
                    <?php 
                          $sharp70 = asset('public/front/Docpro/assets/images/shape/shape-70.png');
                          $sharp71 = asset('public/front/Docpro/assets/images/shape/shape-71.png');
                          $sharp49 = asset('public/front/Docpro/assets/images/shape/shape-49.png');
                          $sharp50 = asset('public/front/Docpro/assets/images/shape/shape-50.png');
                          $sharp54 = asset('public/front/Docpro/assets/images/shape/shape-54.png');
                    ?>
                    <div class="pattern-1" style="background-image: url('{{$sharp70}}');"></div>
                    <div class="pattern-2" style="background-image: url('{{$sharp71}}');"></div>
                </div>
                <div class="auto-container">
                    <div class="title">
                        <h1>{{ $title }}</h1>
                    </div>
                </div>
            </div>
            <div class="lower-content">
                <div class="auto-container">
                    <ul class="bread-crumb clearfix">
                        <li><a href="{{route('home')}}">{{__('message.Home')}}</a></li>
                        <li>{{$title}}</li>
                    </ul>
                </div>
            </div>
        </section>
        <section class="about-style-two">
            <div class="auto-container">
                <div class="row align-items-center clearfix">
                    <div class="col-lg-12 col-md-12 col-sm-12 content-column">
                        <div class="content_block_1">
                            <div class="content-box mr-50">
                                <div class="sec-title">
                                    <p>{{ $title }} {{__('message.site_name')}}</p>
                                    <h2>{{ $title }}</h2>
                                </div>
                                <div class="text">
                                    {!! $content !!}
                                </div>
                                
                                   
                            
                                <!--<div class="btn-box"><a href="{{route('aboutus')}}" class="theme-btn-one">About Us<i class="icon-Arrow-Right"></i></a></div>-->
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-sm-12 image-column">
                        <div class="image_block_3">
                            <div class="image-box">
                                <div class="pattern">
                                    <div class="pattern-1" style="background-image: url('{{$sharp49}}');"></div>
                                    <div class="pattern-2" style="background-image: url('{{$sharp50}}');"></div>
                                    <div class="pattern-3"></div>
                                </div>
                                <figure class="image image-1 paroller" style="transform: unset; transition: transform 0.6s cubic-bezier(0, 0, 0, 1) 0s; will-change: transform;"><img src="{{asset('public/front/Docpro/assets/images/resource/about-4.jpg')}}" alt=""></figure>
                                <figure class="image image-2 paroller-2" style="transform: unset; transition: transform 0.6s cubic-bezier(0, 0, 0, 1) 0s; will-change: transform;"><img src="{{asset('public/front/Docpro/assets/images/resource/about-3.jpg')}}" alt=""></figure>
                              
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="process-style-two bg-color-3 centred">
            <div class="pattern-layer">
                <?php 
                        $sharp39 = asset('public/front/Docpro/assets/images/shape/shape-39.png');
                        $sharp40 = asset('public/front/Docpro/assets/images/shape/shape-40.png');
                        $sharp41 = asset('public/front/Docpro/assets/images/shape/shape-41.png');
                        $sharp42 = asset('public/front/Docpro/assets/images/shape/shape-42.png');
                        $arrow1 = asset('public/front/Docpro/assets/images/icons/arrow-1.png');
                        
                ?>
                <div class="pattern-1" style="background-image: url(<?=$sharp39?>);"></div>
                <div class="pattern-2" style="background-image: url(<?=$sharp40?>);"></div>
                <div class="pattern-3" style="background-image: url(<?=$sharp41?>);"></div>
                <div class="pattern-4" style="background-image: url(<?=$sharp42?>);"></div>
            </div>
            <div class="auto-container">
                <div class="sec-title centred">
                    <p>Process</p>
                    <h2>Test Process</h2>
                </div>
                <div class="inner-content">
                    <div class="arrow" style="background-image: url('{{$arrow1}}');"></div>
                    <div class="row clearfix">
                        <div class="col-lg-4 col-md-6 col-sm-12 processing-block">
                            <div class="processing-block-two">
                                <div class="inner-box">
                                    <figure class="icon-box"><img src="{{asset('public/front/Docpro/assets/images/icons/icon-9.png')}}" alt=""></figure>
                                    <h3>Search Best Online Test</h3>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-12 processing-block">
                            <div class="processing-block-two">
                                <div class="inner-box">
                                    <figure class="icon-box"><img src="{{asset('public/front/Docpro/assets/images/icons/icon-10.png')}}" alt=""></figure>
                                    <h3>View Test Profile</h3>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-12 processing-block">
                            <div class="processing-block-two">
                                <div class="inner-box">
                                    <figure class="icon-box"><img src="{{asset('public/front/Docpro/assets/images/icons/icon-11.png')}}" alt=""></figure>
                                    <h3>Get Instant Book Test</h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="faq-section pt-125">
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="col-lg-6 col-md-12 col-sm-12 image-column">
                        <div class="image_block_4">
                            <div class="image-box">
                                <div class="pattern" style="background-image: url('{{$sharp54}}');"></div>
                                <figure class="image"><img src="{{asset('public/front/Docpro/assets/images/resource/faq-1.png')}}" alt=""></figure>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-sm-12 content-column">
                        <div class="content_block_5">
                            <div class="content-box">
                                <div class="sec-title">
                                    <p>Faq’s</p>
                                    <h2>Frequently Asked Questions.</h2>
                                </div>
                                <ul class="accordion-box">
                                    <li class="accordion block">
                                        <div class="acc-btn">
                                            <div class="icon-outer"></div>
                                            <h4>How to book a test on Reliable website? </h4>
                                        </div>
                                        <div class="acc-content">
                                            <div class="text">
                                                <p>You can book a health test on the healthians website through the following ways

Select a package that best suits your requirements or doctor recommended tests from the "Health Checkup Packages". You will be prompted to update your location on top right of the screen - please select the location for which you wish to see the packages (for example, if you live in Gurgaon, and you wish to check packages for your parents who live in Indore, please select Indore in location prompt.)</p>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="accordion block active-block">
                                        <div class="acc-btn active">
                                            <div class="icon-outer"></div>
                                            <h4> How to book a test on Reliable app?</h4>
                                        </div>
                                        <div class="acc-content current">
                                            <div class="text">
                                                <p>You can book a test on the Healthians Android App with the following steps.

Open the app and select your location. Please select the location for which you wish to see the packages (for example, if you live in Gurgaon, and you wish to check packages for your parents who live in Indore, please select Indore in location prompt.)</p>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="accordion block">
                                         <div class="acc-btn">
                                            <div class="icon-outer"></div>
                                            <h4> You can book a test on the Reliable Android App with the following steps.</h4>
                                        </div>
                                        <div class="acc-content">
                                            <div class="text">
                                                <p>You can chat with our health experts via the chat window at bottom right corner of the website & provide details of your health condition to get the right advice on preferred tests. You can also call us on 999-888-000-5 to get recommendations.</p>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
 
@stop
@section('footer')
@stop