@extends('front.layout')

@php

$cityName = session()->get('cityName');

if($cityName == ''){

$cityName='jaipur';

}

@endphp

@section('title')

Book Full Body Health Checkup Packages in {{$cityName}} | Reliable

@stop

@section('meta-data')
<link rel="canonical" href="{{ url()->current() }}">
<meta name="description"

    content="Book your Entire Full Body Health Checkup test packages online in {{$cityName}} with a home sample collection facility from Reliable Diagnostic Centre at best price.">
<meta name="keywords"

    content="Full Body Checkup Packages in {{$cityName}}, Health Checkup Packages in {{$cityName}},Entire Body Checkup Packages in {{$cityName}}, Reliable Pathology lab in {{$cityName}}">
<meta name="robots" content="index, follow" />
<meta property="og:type" content="website" />
<meta property="og:url" content="{{ url()->current() }}" />
<meta property="og:title" content="Book Full Body Health Checkup Packages in {{$cityName}} | Reliable" />
<meta property="og:image" content="{{asset('public/img/').'/'.$setting->logo}}" />
<meta property="og:image:width" content="250px" />
<meta property="og:image:height" content="250px" />
<meta property="og:site_name" content="{{__('message.site_name')}}" />
<meta property="og:description"

    content="Book your Entire Full Body Health Checkup test packages online in {{$cityName}} with a home sample collection facility from Reliable Diagnostic Centre at best price." />
<meta property="og:keyword"

    content="Full Body Checkup Packages in {{$cityName}}, Health Checkup Packages in {{$cityName}},Entire Body Checkup Packages in {{$cityName}}, Reliable Pathology lab in {{$cityName}}" />
<link rel="shortcut icon" href="{{asset('public/img/').'/'.$setting->favicon}}">
<meta name="viewport" content="width=device-width, initial-scale=1">
@stop

@section('content')
<section class="page-title-two">
  <!--<div class="title-box centred bg-color-2">
    <div class="pattern-layer">
      <?php

            $sharp70 = asset('public/front/Docpro/assets/images/shape/shape-70.png');

            $sharp71 = asset('public/front/Docpro/assets/images/shape/shape-71.png');

            ?>
      <div class="pattern-1" style="background-image: url('{{$sharp70}}');"></div>
      <div class="pattern-2" style="background-image: url('{{$sharp71}}');"></div>
    </div>
    <div class="auto-container">
      <div class="title">
        <h1>Popular Package List</h1>
      </div>
    </div>
  </div>-->
  <div class="lower-content">
    <div class="auto-container">
      <ul class="bread-crumb clearfix">
        <li><a href="{{route('home')}}">{{__('message.Home')}}</a></li>
        <li>{{__('message.Popular Package List')}}</li>
      </ul>
    </div>
  </div>
</section>
<section class="pricing-section bg-color-3 sec-pad">
  <div class="pattern-layer">
    <?php

        $path1 = asset('public/front/Docpro/assets/images/shape/shape-39.png');

        $path2 = asset('public/front/Docpro/assets/images/shape/shape-42.png');

        $arrow1 = asset('public/front/Docpro/assets/images/icons/arrow-1.png');

        $sharp45 = asset('public/front/Docpro/assets/images/shape/shape-45.png');

        $sharp46 = asset('public/front/Docpro/assets/images/shape/shape-46.png');

        $sharp75 = asset('public/front/Docpro/assets/images/shape/shape-75.png');

        $sharp76 = asset('public/front/Docpro/assets/images/shape/shape-76.png');

        $sharp77 = asset('public/front/Docpro/assets/images/shape/shape-77.png');

        ?>
    <div class="pattern-1" style="background-image: url('{{$path1}}');"></div>
    <div class="pattern-4" style="background-image: url('{{$path2}}');"></div>
  </div>
  <div class="auto-container"> 
    
    <!---->
    
    <div class="clinic-block-one">
      <div class="inner-box" style="padding: 34px 40px 37px 34px !important;">
        <div class="row">
          <div class="col-md-6">
            <div class="content-box">
              <ul class="name-box clearfix">
                <li class="name">
                  <h2 id="package_name">Book Full Body Health Checkup Packages in {{$cityName}} |
                    
                    Reliable</h2>
                </li>
              </ul>
              <div class="text">
                <p>Book your Entire Full Body Health Checkup test packages online in {{$cityName}} with
                  
                  a home sample collection facility from Reliable Diagnostic Centre at best price.</p>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="brand-carousel-lab m-0 owl-carousel" style="border: 1px solid #233646;padding: 10px;"> @foreach($labs as $df)
              <div class="testimonial-block-two">
                <div class="text">
                  <p><b> <?php echo substr($df->name, 0, 85) ?> <br>
                    <?php echo substr($df->branch_code, 0, 85) ?> </b></p>
                  <p style="white-space: nowrap; overflow: hidden;text-overflow: ellipsis;"><i

                                            class="fa fa-envelope"></i> : {{$df->email}}</p>
                  <p style="white-space: nowrap; overflow: hidden;text-overflow: ellipsis;"><i

                                            class="fa fa-phone"></i> : {{$df->phone}}</p>
                  <p style=""><i class="fas fa-map"></i> : {{$df->location['name']}}</p>
                </div>
              </div>
              @endforeach </div>
          </div>
        </div>
      </div>
    </div>
    
    <!---->
    
    <div class="inner-content">
      <div class="row clearfix"> 
      @foreach($popular_package as $pl)
        <?php
        $discount=0;
        if($pl->price > 0 ){
            $discount = 100 * ($pl->price - $pl->mrp) / $pl->price; 
        }
        ?>
        <div class="col-lg-4 col-md-6 col-sm-12 pricing-block">
        @include('front.card')
        </div>
      @endforeach 
        </div>
    </div>
  </div>
</section>

@if(isset($contentdata) && !empty($contentdata))
<section class="doctor-details bg-color-3" style="margin-top:-5%">
   <div class="auto-container" style="margin-bottom:-10%">
     <div class="row clearfix">
       <div class="col-lg-12 col-md-12 col-sm-12 content-side">
         <div class="clinic-details-content doctor-details-content">
           <div class="clinic-block-one">
             <div class="inner-box" style="padding: 34px 40px 37px 34px !important;">
               <div class="row">
                 <div class="col-md-12">
                    @foreach($contentdata as $cn)
                    @if($cn->page_name == "Popular-Package")
                    <div class="content-box">
                     <ul class="name-box clearfix">
                       <li class="name">
                         <h3>{{ $cn->name }}</h3>
                       </li>
                     </ul>
                     <div class="text">
                        @php
                            $description = COMMAN::replace($cn->description,$cityName) ;
                         @endphp
                       <p>{!! $description !!}</p>
                     </div>
                   </div>
                   @endif
                   @endforeach
                   
                 </div>
                 
               </div>
             </div>
           </div>
         </div>
       </div>
     </div>
   </div>
 </section><br>
 @endif
 
@stop

@section('footer') 
<script>

    document.querySelectorAll('.more-link').forEach(function (link) {

        link.addEventListener('click', function () {

            var parameterList = this.parentElement.querySelector('.list');

            var hiddenItems = parameterList.querySelectorAll('li:not(:nth-child(-n+4))');



            for (var i = 0; i < hiddenItems.length; i++) {

                hiddenItems[i].style.display = 'block';

            }



            this.style.display = 'none';

            this.parentElement.querySelector('.less-link').style.display = 'inline';

        });

    });



    document.querySelectorAll('.less-link').forEach(function (link) {

        link.addEventListener('click', function () {

            var parameterList = this.parentElement.querySelector('.list');

            var hiddenItems = parameterList.querySelectorAll('li:not(:nth-child(-n+4))');



            for (var i = 0; i < hiddenItems.length; i++) {

                hiddenItems[i].style.display = 'none';

            }



            this.style.display = 'none';

            this.parentElement.querySelector('.more-link').style.display = 'inline';

        });

    });

</script> 
@stop