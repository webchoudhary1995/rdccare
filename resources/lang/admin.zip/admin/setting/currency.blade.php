

    
  <option value="AED - &#1583;.&#1573;">AED - &#1583;.&#1573; </option>

    
  <option value="AFN - &#65;&#102;">AFN - &#65;&#102; </option>

    
  <option value="ALL - &#76;&#101;&#107;">ALL - &#76;&#101;&#107; </option>

    
  <option value="ANG - &#402;">ANG - &#402; </option>

    
  <option value="AOA - &#75;&#122;">AOA - &#75;&#122; </option>

    
  <option value="ARS - &#36;">ARS - &#36; </option>

    
  <option value="AUD - &#36;">AUD - &#36; </option>

    
  <option value="AWG - &#402;">AWG - &#402; </option>

    
  <option value="AZN - &#1084;&#1072;&#1085;">AZN - &#1084;&#1072;&#1085; </option>

    
  <option value="BAM - &#75;&#77;">BAM - &#75;&#77; </option>

    
  <option value="BBD - &#36;">BBD - &#36; </option>

    
  <option value="BDT - &#2547;">BDT - &#2547; </option>

    
  <option value="BGN - &#1083;&#1074;">BGN - &#1083;&#1074; </option>

    
  <option value="BHD - .&#1583;.&#1576;">BHD - .&#1583;.&#1576; </option>

    
  <option value="BIF - &#70;&#66;&#117;">BIF - &#70;&#66;&#117; </option>

    
  <option value="BMD - &#36;">BMD - &#36; </option>

    
  <option value="BND - &#36;">BND - &#36; </option>

    
  <option value="BOB - &#36;&#98;">BOB - &#36;&#98; </option>

    
  <option value="BRL - &#82;&#36;">BRL - &#82;&#36; </option>

    
  <option value="BSD - &#36;">BSD - &#36; </option>

    
  <option value="BTN - &#78;&#117;&#46;">BTN - &#78;&#117;&#46; </option>

    
  <option value="BWP - &#80;">BWP - &#80; </option>

    
  <option value="BYR - &#112;&#46;">BYR - &#112;&#46; </option>

    
  <option value="BZD - &#66;&#90;&#36;">BZD - &#66;&#90;&#36; </option>

    
  <option value="CAD - &#36;">CAD - &#36; </option>

    
  <option value="CDF - &#70;&#67;">CDF - &#70;&#67; </option>

    
  <option value="CHF - &#67;&#72;&#70;">CHF - &#67;&#72;&#70; </option>

    
  <option value="CLP - &#36;">CLP - &#36; </option>

    
  <option value="CNY - &#165;">CNY - &#165; </option>

    
  <option value="COP - &#36;">COP - &#36; </option>

    
  <option value="CRC - &#8353;">CRC - &#8353; </option>

    
  <option value="CUP - &#8396;">CUP - &#8396; </option>

    
  <option value="CVE - &#36;">CVE - &#36; </option>

    
  <option value="CZK - &#75;&#269;">CZK - &#75;&#269; </option>

    
  <option value="DJF - &#70;&#100;&#106;">DJF - &#70;&#100;&#106; </option>

    
  <option value="DKK - &#107;&#114;">DKK - &#107;&#114; </option>

    
  <option value="DOP - &#82;&#68;&#36;">DOP - &#82;&#68;&#36; </option>

    
  <option value="DZD - &#1583;&#1580;">DZD - &#1583;&#1580; </option>

    
  <option value="EGP - &#163;">EGP - &#163; </option>

    
  <option value="ETB - &#66;&#114;">ETB - &#66;&#114; </option>

    
  <option value="EUR - &#8364;">EUR - &#8364; </option>

    
  <option value="FJD - &#36;">FJD - &#36; </option>

    
  <option value="FKP - &#163;">FKP - &#163; </option>

    
  <option value="GBP - &#163;">GBP - &#163; </option>

    
  <option value="GEL - &#4314;">GEL - &#4314; </option>

    
  <option value="GHS - &#162;">GHS - &#162; </option>

    
  <option value="GIP - &#163;">GIP - &#163; </option>

    
  <option value="GMD - &#68;">GMD - &#68; </option>

    
  <option value="GNF - &#70;&#71;">GNF - &#70;&#71; </option>

    
  <option value="GTQ - &#81;">GTQ - &#81; </option>

    
  <option value="GYD - &#36;">GYD - &#36; </option>

    
  <option value="HKD - &#36;">HKD - &#36; </option>

    
  <option value="HNL - &#76;">HNL - &#76; </option>

    
  <option value="HRK - &#107;&#110;">HRK - &#107;&#110; </option>

    
  <option value="HTG - &#71;">HTG - &#71; </option>

    
  <option value="HUF - &#70;&#116;">HUF - &#70;&#116; </option>

    
  <option value="IDR - &#82;&#112;">IDR - &#82;&#112; </option>

    
  <option value="ILS - &#8362;">ILS - &#8362; </option>

    
  <option value="INR - &#8377;">INR - &#8377; </option>

    
  <option value="IQD - &#1593;.&#1583;">IQD - &#1593;.&#1583; </option>

    
  <option value="IRR - &#65020;">IRR - &#65020; </option>

    
  <option value="ISK - &#107;&#114;">ISK - &#107;&#114; </option>

    
  <option value="JEP - &#163;">JEP - &#163; </option>

    
  <option value="JMD - &#74;&#36;">JMD - &#74;&#36; </option>

    
  <option value="JOD - &#74;&#68;">JOD - &#74;&#68; </option>

    
  <option value="JPY - &#165;">JPY - &#165; </option>

    
  <option value="KES - &#75;&#83;&#104;">KES - &#75;&#83;&#104; </option>

    
  <option value="KGS - &#1083;&#1074;">KGS - &#1083;&#1074; </option>

    
  <option value="KHR - &#6107;">KHR - &#6107; </option>

    
  <option value="KMF - &#67;&#70;">KMF - &#67;&#70; </option>

    
  <option value="KPW - &#8361;">KPW - &#8361; </option>

    
  <option value="KRW - &#8361;">KRW - &#8361; </option>

    
  <option value="KWD - &#1583;.&#1603;">KWD - &#1583;.&#1603; </option>

    
  <option value="KYD - &#36;">KYD - &#36; </option>

    
  <option value="KZT - &#1083;&#1074;">KZT - &#1083;&#1074; </option>

    
  <option value="LAK - &#8365;">LAK - &#8365; </option>

    
  <option value="LBP - &#163;">LBP - &#163; </option>

    
  <option value="LKR - &#8360;">LKR - &#8360; </option>

    
  <option value="LRD - &#36;">LRD - &#36; </option>

    
  <option value="LSL - &#76;">LSL - &#76; </option>

    
  <option value="LTL - &#76;&#116;">LTL - &#76;&#116; </option>

    
  <option value="LVL - &#76;&#115;">LVL - &#76;&#115; </option>

    
  <option value="LYD - &#1604;.&#1583;">LYD - &#1604;.&#1583; </option>

    
  <option value="MAD - &#1583;.&#1605;.">MAD - &#1583;.&#1605;. </option>

    
  <option value="MDL - &#76;">MDL - &#76; </option>

    
  <option value="MGA - &#65;&#114;">MGA - &#65;&#114; </option>

    
  <option value="MKD - &#1076;&#1077;&#1085;">MKD - &#1076;&#1077;&#1085; </option>

    
  <option value="MMK - &#75;">MMK - &#75; </option>

    
  <option value="MNT - &#8366;">MNT - &#8366; </option>

    
  <option value="MOP - &#77;&#79;&#80;&#36;">MOP - &#77;&#79;&#80;&#36; </option>

    
  <option value="MRO - &#85;&#77;">MRO - &#85;&#77; </option>

    
  <option value="MUR - &#8360;">MUR - &#8360; </option>

    
  <option value="MVR - .&#1923;">MVR - .&#1923; </option>

    
  <option value="MWK - &#77;&#75;">MWK - &#77;&#75; </option>

    
  <option value="MXN - &#36;">MXN - &#36; </option>

    
  <option value="MYR - &#82;&#77;">MYR - &#82;&#77; </option>

    
  <option value="MZN - &#77;&#84;">MZN - &#77;&#84; </option>

    
  <option value="NAD - &#36;">NAD - &#36; </option>

    
  <option value="NGN - &#8358;">NGN - &#8358; </option>

    
  <option value="NIO - &#67;&#36;">NIO - &#67;&#36; </option>

    
  <option value="NOK - &#107;&#114;">NOK - &#107;&#114; </option>

    
  <option value="NPR - &#8360;">NPR - &#8360; </option>

    
  <option value="NZD - &#36;">NZD - &#36; </option>

    
  <option value="OMR - &#65020;">OMR - &#65020; </option>

    
  <option value="PAB - &#66;&#47;&#46;">PAB - &#66;&#47;&#46; </option>

    
  <option value="PEN - &#83;&#47;&#46;">PEN - &#83;&#47;&#46; </option>

    
  <option value="PGK - &#75;">PGK - &#75; </option>

    
  <option value="PHP - &#8369;">PHP - &#8369; </option>

    
  <option value="PKR - &#8360;">PKR - &#8360; </option>

    
  <option value="PLN - &#122;&#322;">PLN - &#122;&#322; </option>

    
  <option value="PYG - &#71;&#115;">PYG - &#71;&#115; </option>

    
  <option value="QAR - &#65020;">QAR - &#65020; </option>

    
  <option value="RON - &#108;&#101;&#105;">RON - &#108;&#101;&#105; </option>

    
  <option value="RSD - &#1044;&#1080;&#1085;&#46;">RSD - &#1044;&#1080;&#1085;&#46; </option>

    
  <option value="RUB - &#1088;&#1091;&#1073;">RUB - &#1088;&#1091;&#1073; </option>

    
  <option value="RWF - &#1585;.&#1587;">RWF - &#1585;.&#1587; </option>

    
  <option value="SAR - &#65020;">SAR - &#65020; </option>

    
  <option value="SBD - &#36;">SBD - &#36; </option>

    
  <option value="SCR - &#8360;">SCR - &#8360; </option>

    
  <option value="SDG - &#163;">SDG - &#163; </option>

    
  <option value="SEK - &#107;&#114;">SEK - &#107;&#114; </option>

    
  <option value="SGD - &#36;">SGD - &#36; </option>

    
  <option value="SHP - &#163;">SHP - &#163; </option>

    
  <option value="SLL - &#76;&#101;">SLL - &#76;&#101; </option>

    
  <option value="SOS - &#83;">SOS - &#83; </option>

    
  <option value="SRD - &#36;">SRD - &#36; </option>

    
  <option value="STD - &#68;&#98;">STD - &#68;&#98; </option>

    
  <option value="SVC - &#36;">SVC - &#36; </option>

    
  <option value="SYP - &#163;">SYP - &#163; </option>

    
  <option value="SZL - &#76;">SZL - &#76; </option>

    
  <option value="THB - &#3647;">THB - &#3647; </option>

    
  <option value="TJS - &#84;&#74;&#83;">TJS - &#84;&#74;&#83; </option>

    
  <option value="TMT - &#109;">TMT - &#109; </option>

    
  <option value="TND - &#1583;.&#1578;">TND - &#1583;.&#1578; </option>

    
  <option value="TOP - &#84;&#36;">TOP - &#84;&#36; </option>

    
  <option value="TRY - &#8356;">TRY - &#8356; </option>

    
  <option value="TTD - &#36;">TTD - &#36; </option>

    
  <option value="TWD - &#78;&#84;&#36;">TWD - &#78;&#84;&#36; </option>

    
  <option value="UAH - &#8372;">UAH - &#8372; </option>

    
  <option value="UGX - &#85;&#83;&#104;">UGX - &#85;&#83;&#104; </option>

    
  <option value="USD - &#36;">USD - &#36; </option>

    
  <option value="UYU - &#36;&#85;">UYU - &#36;&#85; </option>

    
  <option value="UZS - &#1083;&#1074;">UZS - &#1083;&#1074; </option>

    
  <option value="VEF - &#66;&#115;">VEF - &#66;&#115; </option>

    
  <option value="VND - &#8363;">VND - &#8363; </option>

    
  <option value="VUV - &#86;&#84;">VUV - &#86;&#84; </option>

    
  <option value="WST - &#87;&#83;&#36;">WST - &#87;&#83;&#36; </option>

    
  <option value="XAF - &#70;&#67;&#70;&#65;">XAF - &#70;&#67;&#70;&#65; </option>

    
  <option value="XCD - &#36;">XCD - &#36; </option>

    
  <option value="XPF - &#70;">XPF - &#70; </option>

    
  <option value="YER - &#65020;">YER - &#65020; </option>

    
  <option value="ZAR - &#82;">ZAR - &#82; </option>

    
  <option value="ZMK - &#90;&#75;">ZMK - &#90;&#75; </option>

    
  <option value="ZWL - &#90;&#36;">ZWL - &#90;&#36; </option>
