@extends('manager.layout.index')
@section('title')
{{__("message.Dashboard")}}
@stop
@section('content')
<?php
function random_color_part() {
    return str_pad( dechex( mt_rand( 0, 255 ) ), 2, '0', STR_PAD_LEFT);
}

function random_color() {
    return "#".random_color_part() . random_color_part() . random_color_part();
}
$totalsales = 0;
$currency = '$';
 ?>
<!--Page header-->
<div class="page-header">
	<div class="page-leftheader">
		<h4 class="page-title mb-0 text-primary">{{__("message.Dashboard")}}</h4>
	</div>				
</div>
<!--End Page header-->
<!-- Row-1 -->
<div class="row">
	<div class="col-sm-12 col-md-6 col-xl-3">
      <div class="card" style="background-color: <?=random_color()?>;">
         <div class="card-body">
            <div class="d-flex no-block align-items-center">
               <div>
                  <h6 class="text-white">{{__("message.Total Orders")}}</h6>
                  <h2 class="text-white m-0 font-weight-bold">{{$totalorder}}</h2>
               </div>
               <div class="ms-auto"> <span class="text-white display-6"><i class="fab fa-first-order fa-2x"></i></span> </div>
            </div>
         </div>
      </div>
   </div>
   	<div class="col-sm-12 col-md-6 col-xl-3">
      <div class="card" style="background-color: <?=random_color()?>;">
         <div class="card-body">
            <div class="d-flex no-block align-items-center">
               <div>
                  <h6 class="text-white">{{__("message.Total Complete Orders")}}</h6>
                  <h2 class="text-white m-0 font-weight-bold">{{$totalcomplete}}</h2>
               </div>
               <div class="ms-auto"> <span class="text-white display-6"><i class="fas fa-tasks fa-2x"></i></span> </div>
            </div>
         </div>
      </div>
   </div>
   	<div class="col-sm-12 col-md-6 col-xl-3">
      <div class="card" style="background-color: <?=random_color()?>;">
         <div class="card-body">
            <div class="d-flex no-block align-items-center">
               <div>
                  <h6 class="text-white">{{__("message.Total Pending Orders")}}</h6>
                  <h2 class="text-white m-0 font-weight-bold">{{$totalpending}}</h2>
               </div>
               <div class="ms-auto"> <span class="text-white display-6"><i class="fas fa-spinner fa-2x"></i></span> </div>
            </div>
         </div>
      </div>
   </div>
   <div class="col-sm-12 col-md-6 col-xl-3">
      <div class="card" style="background-color: <?=random_color()?>;">
         <div class="card-body">
            <div class="d-flex no-block align-items-center">
               <div>
                  <h6 class="text-white">{{__("message.Total Rejected Orders")}}</h6>
                  <h2 class="text-white m-0 font-weight-bold">{{$totalreject}}</h2>
               </div>
               <div class="ms-auto"> <span class="text-white display-6"><i class="fas fa-spinner fa-2x"></i></span> </div>
            </div>
         </div>
      </div>
   </div>			
</div>
<div class="row">
	<div class="col-lg-12 grid-margin stretch-card">
       <div class="card">  
         <div class="card-header">
         	<div class="card-title">{{__("message.Today Collecting Order")}}</div>
         </div>              	
         <div class="card-body">
	 <div class="table-responsive">
               <table id="TodayOrdersTable" class="table table-bordered text-nowrap dataTable no-footer">
                  <thead>
                     <tr>
                        <th>{{__("message.Id")}}</th>
                        <th>{{__("message.Customer Name")}}</th>
                        <th>{{__("message.Address")}}</th>
                        <th>{{__("message.Sample Collection DateTime")}}</th>
                        <th>{{__("message.Payment Method")}}</th>
                        <th>{{__("message.Paid Amount")}}</th>
                        <th>{{__("message.More")}}</th>
                        <th>{{__("message.Print")}}</th>
                        <th>{{__("message.Status")}}</th>
                        <th>{{__("message.Action")}}</th>
                     </tr>
                  </thead>
                  <tbody>                        
                  </tbody>
                  <tfoot>
                     <th>{{__("message.Id")}}</th>
                     <th>{{__("message.Customer Name")}}</th>
                     <th>{{__("message.Address")}}</th>
                     <th>{{__("message.Sample Collection DateTime")}}</th>
                     <th>{{__("message.Payment Method")}}</th>
                     <th>{{__("message.Paid Amount")}}</th>
                     <th>{{__("message.More")}}</th>
                     <th>{{__("message.Print")}}</th>
                     <th>{{__("message.Status")}}</th>
                     <th>{{__("message.Action")}}</th>
                  </tfoot>
               </table>
            </div>
        </div>
    </div>
</div>
</div>
<!-- End Row-1 -->
@endsection