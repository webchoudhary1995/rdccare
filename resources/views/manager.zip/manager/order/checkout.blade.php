@extends('manager.layout.index')
@section('title')
{{__("message.Orders List")}}
@stop
@section('content')
<style>
     .custom-select {
            /* Add your desired styling here */
            background-color: #f2f2f2;
            color: #333;
            border: 1px solid #ccc;
            padding: 8px;
            font-size: 14px;
            width: 200px; /* Set a specific width or adjust as per your requirements */
        } 
.applied-coupon {
            background-color: #4CAF50; /* Green color for applied coupon */
            color: green;
        }
        .cards-container {
            display: flex;
            justify-content: center;
            gap: 20px;
            max-width: 800px;
            padding:25px;
        }

        .cardcp {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 250px;
            text-align: center;
            transition: transform 0.2s;
        }

        .cardcp:hover {
            transform: translateY(-5px);
        }

        .coupon-code {
            font-size: 24px;
            font-weight: bold;
        }

        .coupon-value {
            font-size: 18px;
            color: #4CAF50;
            margin: 10px 0;
        }

        .coupon-type {
            font-size: 14px;
            color: #888;
            height:70px;
            overflow:hidden;
        }
    </style>

<div class="page-header">
   <h3 class="page-title">{{__("message.Orders List")}}</h3>
   <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
         <li class="breadcrumb-item"><a href="{{route('manager-dashboard')}}">{{__("message.Home")}}</a></li>
         <li class="breadcrumb-item active">{{__("message.Orders List")}}</li>
      </ol>
   </nav>
</div>
<div class="row">
   <div class="col-lg-12 grid-margin stretch-card">
      <div class="card">
         <div class="card-body">
            @if(Session::has('message'))
            <div class="col-sm-12">
               <div class="alert  {{ Session::get('alert-class', 'alert-info') }} alert-dismissible fade show" role="alert">{{ Session::get('message') }}
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                  </button>
               </div>
            </div>
            @endif
            <div class="table-responsive">
               <table  class="table table-bordered text-nowrap dataTable no-footer">
                     @php
                      $total = 0;
                     @endphp
                     <tr>
                        <th>Order Id</th> 
                        <th>Test Name</th>
                        <th>{{__("message.Test Type")}}</th>
                        <th>{{__("message.Parameter")}}</th>
                        <th>{{__("message.MRP")}}</th>
                        <th>{{__("message.Price")}}</th>
                     </tr>

                     @foreach($cart as $row)
                     <tr>
                     <?php $total = $total+$row['price']; ?>

                        <td>{{ $row['id'] }}</td>
                        <td>{{ $row['test_name'] }}</td>
                        <td>
                           @if($row['type'] ==1 )
                              Package
                           @elseif($row['type'] ==2)
                              Parameter
                           @else
                              Profile
                           @endif
                        </td>
                        <td>{{ $row['parameter'] }}</td>
                        <td>{{ $row['mrp'] }}</td>
                        <td>{{ $row['price'] }}</td>
                        
                     </tr>
                     @endforeach
                  
                  
               </table>
            </div>
            
         </div>
      </div> 
   </div>

   <!-------------------coupon--------------------------->
   @if(count($coupon)>0)
                  <div class="panel panel-default">
                     <div class="panel-heading" role="tab" id="heading3">
                        <h4 class="panel-title">
                           @if(Auth::id())
                           <a role="button"  data-parent="#accordion" data-toggle="collapse"  href="#collapse3" aria-expanded="true" aria-controls="collapse3"><i class="fa fa-address-card checkicon"></i>Apply Coupon </a>
                           @else
                           <a role="button" data-toggle="collapse"  href="javascript::void(0)" aria-expanded="true" aria-controls="collapse3"><i class="fa fa-address-card checkicon"></i>Apply Coupon </a>
                           @endif
                        </h4>
                     </div>
                     <div id="collapse3" class="panel-collapse collapse show" role="tabpanel" aria-labelledby="heading3">
                        <div class="cards-container">
                              @foreach($coupon as $cp)
                             <div class="cardcp" id="coupon{{ $cp->id }}">
                                <div class="coupon-code">{{ $cp->coupon_code }}</div>
                                <div class="coupon-value">{{ $cp->coupon_value }} @if($cp->coupon_type == 'percent' ) % @else Rs @endif off On</div>
                                <div class="coupon-type" > @if($cp->type == 4) {{ 'All'}} @endif 
                                @if($cp->type == 1) {{ 'Package'}} @endif
                                @if($cp->type == 3)  {{ 'Profile' }} @endif 
                                @if($cp->type == 2)  {{ 'Parameter' }} @endif
                                </div>
                                <div class="coupon-type" > {{$cp->day}} </div>
                                 <?php
                                 $price = 0;
                                // $today = date('l');
                                // echo "Today is $today";
                                ?>
                                <button class="apply-button" onclick="toggleCoupon('{{ $cp->id }}','{{ $price }}','{{ $cp->coupon_type }}','{{ $cp->coupon_value }}')">
                                    {{ $cp->is_applied ? 'Applied' : 'Apply Coupon' }}
                                </button>
                            </div>
                              @endforeach
                        </div>
                       
                     </div>
                  </div>
                  
                  @endif

                  
                  <div class="col-xl-12 col-lg-12 col-md-12 doctors-block" style="margin-top: 10px;">
                     <div class="team-block-three">
                        <div class="inner-box">
                           <div class="lower-content">
                              <ul class="name-box clearfix">
                                 <li class="name" style="display: list-item;">
                                    <div class="row">
                                       <div class="col-md-8">
                                          <h3><a href="#">{{__('message.Sub Total')}}</a></h3>
                                       </div>
                                       <div class="col-md-4">
                                          <p style="float: right;">{{$currency}}<span id="subtotal">{{number_format($total,2,'.','')}}</span></p>
                                       </div>
                                    </div>
                                 </li>
                                 <li class="name" style="display: list-item;">
                                    <div class="row">
                                       <div class="col-md-8">
                                          <h3><a href="#">Coupon Discount</a></h3>
                                       </div>
                                       <div class="col-md-4">
                                          <p style="float: right;">{{$currency}}<span id="discount">0</span></p>
                                       </div>
                                    </div>
                                 </li>
                                 <!-- <li class="name" style="display: list-item;">
                                    <div class="row">
                                       <div class="col-md-8">
                                          <h3><a href="#">Wallet Point Discount</a></h3>
                                       </div>
                                       <div class="col-md-4">
                                          <p style="float: right;">{{$currency}}<span id="wal_discount">0</span></p>
                                       </div>
                                    </div>
                                 </li> -->
                                 <li class="name" style="display: list-item;" >
                                    <div class="row">
                                       <div class="col-md-8">
                                          <h3><a href="#">{{__('message.Txt')}}</a></h3>
                                       </div>
                                       <div class="col-md-4">
                                          <?php $txt = ($total*$setting->txt_charge)/100;?>
                                          <p style="float: right;">{{$currency}}<span id="txt_charges">{{number_format($txt,2,'.','')}}</span></p>
                                       </div>
                                    </div>
                                 </li>
                                 <li class="name" style="display: list-item;">
                                    <div class="row">
                                       <div class="col-md-8">

                                          <h3><a href="#">{{__('message.Total')}}</a></h3>
                                       </div>
                                       <div class="col-md-4">
                                          <?php $final_total =  $total + $txt;?>
                                          <p style="float: right;">{{$currency}}<span id="main_total">{{number_format($final_total,2,'.','')}}</span></p>
                                       </div>
                                    </div>
                                 </li>
                              </ul>
                           </div>
                        </div>
                     </div>
                  </div>
  
 <input name="coupon_id" type="hidden"  id="coupon_id">
 <input name="book_test" type="hidden" id="book_test" value="{{json_encode($cart);}}">
 <input name="final_total" type="hidden" id="final_total_vl" value="{{$final_total}}">
 <input name="subtotal" type="hidden"  id="subtotal_vl" value="{{$total}}">
 <input name="order_id" type="hidden" id="order_id_vl" value="{{ $order_id}}">
 <input name="tax" type="hidden" id="tx" value="{{$txt}}">

 <button type="submit" class="btn btn-success" id="verifyButton">Check Out</button>



</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>

    $(document).ready(function() {
        $('#verifyButton').click(function() {
         console.log($('#book_test').val());
            var coupon_id = $('#coupon_id').val();
            var book_test = $('#book_test').val();
            var final_total = $('#final_total_vl').val();
            var subtotal = $('#subtotal_vl').val();
            var tx = $('#tx').val();
            var order_id = $('#order_id_vl').val();

            $.ajax({
                url: 'sampleboy_by_check_out',
                type: 'GET',
                data: { tax:tx,order_id:order_id,coupon_id: coupon_id,book_test:book_test ,final_total:final_total,subtotal:subtotal},
                success: function(response) {
                    console.log(response);
                    if (response.success) {
                        window.location.href = '{{ route("manager-orders") }}';
                    } else {
                     alert('something went wrong');
                    }
                },
                
            });
        });
    });

   function toggleCoupon(couponId,price,type,value) {
            var subtotal = <?php echo $final_total; ?>  ;
            var book_test = $('#book_test').val();

            $.ajax({
            url: 'applycoupons',
            type: 'GET',
            data: {
                id: couponId,
                subtotal: subtotal,
                book_test:book_test
            },
            dataType: 'json',
                success: function (data) {
                    
                    console.log(data);
                  //  if(data != 0){
            const cards = document.querySelectorAll('.cardcp');
            cards.forEach(card => {
                card.classList.remove('applied-coupon');
                const button = card.querySelector('.apply-button');
                button.innerText = 'Apply coupon';
            });

            const selectedCard = document.getElementById(`coupon${couponId}`);
            console.log(selectedCard);
            if (selectedCard) {
                selectedCard.classList.add('applied-coupon');
                const button = selectedCard.querySelector('.apply-button');
                button.innerText = 'Applied';
                const couponCode = selectedCard.querySelector('.coupon-code').innerText;
                const couponValue = selectedCard.querySelector('.coupon-value').innerText;
                const couponType = selectedCard.querySelector('.coupon-type').innerText;
                
             
                
              var final_total = <?php echo $final_total; ?>  - data ;

                 $("#discount").html(data);
                 $("#main_total").html(final_total.toFixed(2));
                 $("#coupon_id").val(couponId);
           // }
                    }
                },
            });
            
        }
</script>
@endsection