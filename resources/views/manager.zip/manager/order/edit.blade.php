@extends('manager.layout.index')
@section('title')
{{__("message.Orders List")}}
@stop
@section('content')
<div class="page-header">
   <h3 class="page-title">{{__("message.Orders List")}}</h3>
   <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
         <li class="breadcrumb-item"><a href="{{route('manager-dashboard')}}">{{__("message.Home")}}</a></li>
         <li class="breadcrumb-item active">{{__("message.Orders List")}}</li>
      </ol>
   </nav>
</div>
<div class="row">
   <div class="col-lg-12 grid-margin stretch-card">
      <div class="card">
         <div class="card-body">
            @if(Session::has('message'))
            <div class="col-sm-12">
               <div class="alert  {{ Session::get('alert-class', 'alert-info') }} alert-dismissible fade show" role="alert">{{ Session::get('message') }}
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                  </button>
               </div>
            </div>
            @endif
            <div class="table-responsive">
               <table  class="table table-bordered text-nowrap dataTable no-footer">
                     @php
                     $trashedItems = []; // Initialize an empty array to store trashed IDs
                     $bookedItems = [];
                     @endphp
                     <tr>
                        <th>Order Id</th> 
                        <th>Test Name</th>
                        <th>{{__("message.Test Type")}}</th>
                        <th>{{__("message.Parameter")}}</th>
                        <th>{{__("message.MRP")}}</th>
                        <th>{{__("message.Price")}}</th>
                        <th>{{__("message.Action")}}</th>
                     </tr>

                     @foreach($data as $row)
                     <tr>
                        <td>{{ $row['id'] }}</td>
                        <td>{{ $row['test_name'] }}</td>
                        <td>
                           @if($row['type'] ==1 )
                              Package
                           @elseif($row['type'] ==2)
                              Parameter
                           @else
                              Profile
                           @endif
                        </td>
                        <td>{{ $row['parameter'] }}</td>
                        <td>{{ $row['mrp'] }}</td>
                        <td>{{ $row['price'] }}</td>
                        <td>
                        <span>
                           <a style="color: red;"  onclick="toggleIcon(this, {{ $row['id'] }}, {{ $row['type'] }}, {{ $row['item_id'] }})">
                                 <i class="fa fa-trash"></i>
                           </a>
                        </span>
                        </td>
                     </tr>
                     @endforeach
                  
                  
               </table>
            </div>
            
         </div>
      </div>
   </div>
   <form action="{{ route('sampleboy_check_out')}}" method="post">
      @csrf
 <input name="trsh" type="hidden" id="trs">
 <input name="book" type="hidden" id="book">
 <input name="order_id" type="hidden" value="{{ $order_id}}">
 <input type="submit" class="btn btn-success"  value="Check Out" data-original-title="banner">

</form>

</div>

<div class="page-header">
   <h3 class="page-title">Other Test List</h3>
</div>
<div class="row">
   <div class="col-lg-12 grid-margin stretch-card">
      <div class="card">
         <div class="card-body">
           
            <div class="table-responsive">
               <table id="OrderschangeTable" class="table table-bordered text-nowrap dataTable no-footer">
                  <thead>
                     <tr>
                        <th>{{__("message.Id")}}</th>
                        <th>{{__("message.Name")}}</th>
                        <th>{{__("message.Type")}}</th>
                        <th>{{__("message.MRP")}}</th>
                        <th>{{__("message.Price")}}</th>
                        <th>{{__("message.Parameters")}}</th>
                        <th>{{__("message.Action")}}</th>
                     </tr>
                  </thead>
                  <tbody>                        
                  </tbody>
                  <tfoot>
                     
                        <th>{{__("message.Id")}}</th>
                        <th>{{__("message.Name")}}</th>
                        <th>{{__("message.Type")}}</th>
                        <th>{{__("message.MRP")}}</th>
                        <th>{{__("message.Price")}}</th>
                        <th>{{__("message.Parameters")}}</th>
                        <th>{{__("message.Action")}}</th>
                  </tfoot>
               </table>
            </div>
         </div>
      </div>
   </div>
</div>


<script>
    var trashedItems = @json($trashedItems); // Convert the PHP array to a JavaScript array

    function toggleIcon(element, id, type, item_id) {
        var icon = element.querySelector('i');
        if (icon.classList.contains('fa-trash')) {
            icon.classList.remove('fa-trash');
            icon.classList.add('fa-minus');
            // Add the ID, type, and item_id to the array as an object
            trashedItems.push({ id: id, type: type, item_id: item_id });
        } else {
            icon.classList.remove('fa-minus');
            icon.classList.add('fa-trash');
            // Remove the item from the array based on id, type, and item_id
            trashedItems = trashedItems.filter(item => item.id != id || item.type != type || item.item_id != item_id);
        }
        console.log('Trashed Items:', trashedItems); // Log the array of trashed items
        $('#trs').val(JSON.stringify(trashedItems));

        // You can send the trashedItems array to the server via an AJAX request here.
        // For example, you can use the fetch API or jQuery AJAX to send the data to the server.
    }
</script>
<script>
var bookedItems = @json($bookedItems);
function togglebook(element, item_id, type,parameter) {
    var button = element;
    if (button.classList.contains('booked')) {
        // If the button is already booked, remove it from the array
        var index = bookedItems.findIndex(item => item.item_id == item_id && item.type == type && item.parameter == parameter);
        if (index !== -1) {
            bookedItems.splice(index, 1);
        }
        button.classList.remove('booked');
        button.classList.remove('btn-primary'); // Remove the primary color class
        button.innerText = 'BOOK NOW';
    } else {
        // If the button is not booked, add it to the array
        bookedItems.push({ item_id: item_id, type: type ,parameter:parameter });
        button.classList.add('booked');
        button.classList.add('btn-primary'); // Add the primary color class
        button.innerText = 'BOOKED';
    }
    console.log('Booked Items:', bookedItems);
    $('#book').val(JSON.stringify(bookedItems));



    // You can send the bookedItems array to the server via an AJAX request here.
    // For example, you can use the fetch API or jQuery AJAX to send the data to the server.
}

</script>
@endsection